const interopDefault = r => r.default || r || [];
const styles = {
  "pages/index.vue": () => import('./index-styles.e4cce81f.mjs').then(interopDefault),
  "layouts/products.vue": () => import('./products-styles.0c129674.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./default-styles.699678ef.mjs').then(interopDefault),
  "error.vue": () => import('./error-styles.cf51eb84.mjs').then(interopDefault),
  "pages/about.vue": () => import('./about-styles.e4a9da4c.mjs').then(interopDefault),
  "components/ProductCard.vue": () => import('./ProductCard-styles.698ace3b.mjs').then(interopDefault),
  "components/ProductDetails.vue": () => import('./ProductDetails-styles.9a37ce0a.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
