import { defineEventHandler } from 'h3';

const nuxt = defineEventHandler(() => {
  return {
    message: `Hello`
  };
});

export { nuxt as default };
//# sourceMappingURL=nuxt.mjs.map
