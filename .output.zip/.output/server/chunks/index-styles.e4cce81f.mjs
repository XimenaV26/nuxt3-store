const index_vue_vue_type_style_index_0_scoped_86e2f27e_lang = "h2[data-v-86e2f27e]{font-size:36px;margin-bottom:20px}p[data-v-86e2f27e]{margin:20px 0}";

const indexStyles_e4cce81f = [index_vue_vue_type_style_index_0_scoped_86e2f27e_lang];

export { indexStyles_e4cce81f as default };
//# sourceMappingURL=index-styles.e4cce81f.mjs.map
