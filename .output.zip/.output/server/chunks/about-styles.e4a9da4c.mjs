const about_vue_vue_type_style_index_0_scoped_e9f8b205_lang = "h2[data-v-e9f8b205]{font-size:36px;margin-bottom:20px}p[data-v-e9f8b205]{margin:20px 0}";

const aboutStyles_e4a9da4c = [about_vue_vue_type_style_index_0_scoped_e9f8b205_lang];

export { aboutStyles_e4a9da4c as default };
//# sourceMappingURL=about-styles.e4a9da4c.mjs.map
