const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<title>Nuxt store</title>\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<meta name=\"Product store with Nuxt 3\" content=\"Product store develop with Nuxt 3\">\n<link rel=\"stylesheet \" href=\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0\">","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
