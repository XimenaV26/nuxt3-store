const ProductDetails_vue_vue_type_style_index_0_scoped_b9205fc6_lang = ".btn[data-v-b9205fc6]{align-items:center;background-color:#63b2b2;border-radius:5px;color:#fff;height:38px;width:100px}img[data-v-b9205fc6]{max-width:400px}";

const ProductDetailsStyles_9a37ce0a = [ProductDetails_vue_vue_type_style_index_0_scoped_b9205fc6_lang];

export { ProductDetailsStyles_9a37ce0a as default };
//# sourceMappingURL=ProductDetails-styles.9a37ce0a.mjs.map
