const client_manifest = {
  "_app.config.1e8d9f57.js": {
    "resourceType": "script",
    "module": true,
    "file": "app.config.1e8d9f57.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_composables.0f656c15.js": {
    "resourceType": "script",
    "module": true,
    "file": "composables.0f656c15.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_fetch.6908980b.js": {
    "resourceType": "script",
    "module": true,
    "file": "fetch.6908980b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_nuxt-link.4a4ba48e.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.4a4ba48e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.7369eea1.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "default.06b46061.js",
    "imports": [
      "_nuxt-link.4a4ba48e.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.7369eea1.css": {
    "file": "default.7369eea1.css",
    "resourceType": "style"
  },
  "layouts/products.css": {
    "resourceType": "style",
    "file": "products.c1c0297b.css",
    "src": "layouts/products.css"
  },
  "layouts/products.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "products.18890ec5.js",
    "imports": [
      "_nuxt-link.4a4ba48e.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "isDynamicEntry": true,
    "src": "layouts/products.vue"
  },
  "products.c1c0297b.css": {
    "file": "products.c1c0297b.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.c46d77ab.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.c46d77ab.css"
    ],
    "dynamicImports": [
      "layouts/default.vue",
      "layouts/products.vue",
      "virtual:nuxt:C:/Users/XINEMA/product-store/.nuxt/error-component.mjs"
    ],
    "file": "entry.c1afe065.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.mjs"
  },
  "entry.c46d77ab.css": {
    "file": "entry.c46d77ab.css",
    "resourceType": "style"
  },
  "pages/about.css": {
    "resourceType": "style",
    "file": "about.e5c0ae59.css",
    "src": "pages/about.css"
  },
  "pages/about.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "about.d95f02db.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.6908980b.js",
      "_app.config.1e8d9f57.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/about.vue"
  },
  "about.e5c0ae59.css": {
    "file": "about.e5c0ae59.css",
    "resourceType": "style"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.405a5b9c.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.bb763c95.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.405a5b9c.css": {
    "file": "index.405a5b9c.css",
    "resourceType": "style"
  },
  "pages/products/[id].css": {
    "resourceType": "style",
    "file": "_id_.9cd78250.css",
    "src": "pages/products/[id].css"
  },
  "pages/products/[id].vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "_id_.9cd78250.css"
    ],
    "file": "_id_.8de5c762.js",
    "imports": [
      "_composables.0f656c15.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.6908980b.js",
      "_app.config.1e8d9f57.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/products/[id].vue"
  },
  "_id_.9cd78250.css": {
    "file": "_id_.9cd78250.css",
    "resourceType": "style"
  },
  "pages/products/index.css": {
    "resourceType": "style",
    "file": "index.99e370b5.css",
    "src": "pages/products/index.css"
  },
  "pages/products/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.99e370b5.css"
    ],
    "file": "index.36638cd3.js",
    "imports": [
      "_nuxt-link.4a4ba48e.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_composables.0f656c15.js",
      "_fetch.6908980b.js",
      "_app.config.1e8d9f57.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/products/index.vue"
  },
  "index.99e370b5.css": {
    "file": "index.99e370b5.css",
    "resourceType": "style"
  },
  "virtual:nuxt:C:/Users/XINEMA/product-store/.nuxt/error-component.css": {
    "resourceType": "style",
    "file": "error-component.3395f153.css",
    "src": "virtual:nuxt:C:/Users/XINEMA/product-store/.nuxt/error-component.css"
  },
  "virtual:nuxt:C:/Users/XINEMA/product-store/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-component.3395f153.css"
    ],
    "file": "error-component.cd93f62a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_app.config.1e8d9f57.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:C:/Users/XINEMA/product-store/.nuxt/error-component.mjs"
  },
  "error-component.3395f153.css": {
    "file": "error-component.3395f153.css",
    "resourceType": "style"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
