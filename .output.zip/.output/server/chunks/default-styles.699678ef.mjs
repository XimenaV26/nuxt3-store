const default_vue_vue_type_style_index_0_scoped_8b63530f_lang = ".router-link-exact-active[data-v-8b63530f]{color:#12b488}";

const defaultStyles_699678ef = [default_vue_vue_type_style_index_0_scoped_8b63530f_lang];

export { defaultStyles_699678ef as default };
//# sourceMappingURL=default-styles.699678ef.mjs.map
