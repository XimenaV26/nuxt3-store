const error_vue_vue_type_style_index_0_scoped_661a13f1_lang = ".btn[data-v-661a13f1]{background-color:#63b2b2;border-radius:5px;color:#fff;height:50px}";

const errorStyles_cf51eb84 = [error_vue_vue_type_style_index_0_scoped_661a13f1_lang];

export { errorStyles_cf51eb84 as default };
//# sourceMappingURL=error-styles.cf51eb84.mjs.map
