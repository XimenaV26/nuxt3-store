const ProductCard_vue_vue_type_style_index_0_scoped_576b7cfc_lang = ".thumb[data-v-576b7cfc]{margin:0 auto;max-height:120px;max-width:70%}.card[data-v-576b7cfc]{border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,.05),0 0 1px rgba(0,0,0,.24)}.card[data-v-576b7cfc]:hover{box-shadow:0 2px 4px rgba(0,0,0,.05),0 0 5px rgba(0,0,0,.24)}.btn[data-v-576b7cfc]{background-color:#63b2b2;border-radius:5px;color:#fff}";

const ProductCardStyles_698ace3b = [ProductCard_vue_vue_type_style_index_0_scoped_576b7cfc_lang];

export { ProductCardStyles_698ace3b as default };
//# sourceMappingURL=ProductCard-styles.698ace3b.mjs.map
