const products_vue_vue_type_style_index_0_scoped_2fa173d5_lang = ".router-link-exact-active[data-v-2fa173d5]{color:#12b488}";

const productsStyles_0c129674 = [products_vue_vue_type_style_index_0_scoped_2fa173d5_lang];

export { productsStyles_0c129674 as default };
//# sourceMappingURL=products-styles.0c129674.mjs.map
