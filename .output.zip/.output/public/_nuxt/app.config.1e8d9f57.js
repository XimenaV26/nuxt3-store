import{y as n}from"./entry.c1afe065.js";const i={};n(i);
